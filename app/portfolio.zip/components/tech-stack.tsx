"use client"

import { motion } from "framer-motion"

const technologies = [
  "Next.js",
  "React",
  "TypeScript",
  "Node.js",
  "Python",
  "AWS",
  "PostgreSQL",
  "MongoDB",
  "Docker",
  "Kubernetes",
  "GraphQL",
  "Redis",
]

const technologies2 = [
  "Tailwind CSS",
  "Prisma",
  "Vercel",
  "GitHub",
  "Figma",
  "Stripe",
  "Firebase",
  "Supabase",
  "OpenAI",
  "Terraform",
  "Go",
  "Rust",
]

export function TechStack() {
  return (
    <section id="tech" className="py-32 bg-black relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 mb-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">
            Technologies
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-white mt-4">
            Our Tech Stack
          </h2>
          <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
            We work with cutting-edge technologies to deliver exceptional results
          </p>
        </motion.div>
      </div>

      {/* Marquee Row 1 */}
      <div className="relative mb-6">
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-black to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black to-transparent z-10" />
        <motion.div
          animate={{ x: [0, -1920] }}
          transition={{
            x: { repeat: Infinity, repeatType: "loop", duration: 30, ease: "linear" },
          }}
          className="flex gap-6"
        >
          {[...technologies, ...technologies, ...technologies].map((tech, i) => (
            <div
              key={`${tech}-${i}`}
              className="flex-shrink-0 px-8 py-4 rounded-full border border-white/10 bg-white/5 backdrop-blur-sm hover:border-blue-500/50 transition-colors"
            >
              <span className="text-white font-medium whitespace-nowrap">{tech}</span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Marquee Row 2 - Reverse Direction */}
      <div className="relative">
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-black to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black to-transparent z-10" />
        <motion.div
          animate={{ x: [-1920, 0] }}
          transition={{
            x: { repeat: Infinity, repeatType: "loop", duration: 30, ease: "linear" },
          }}
          className="flex gap-6"
        >
          {[...technologies2, ...technologies2, ...technologies2].map((tech, i) => (
            <div
              key={`${tech}-${i}`}
              className="flex-shrink-0 px-8 py-4 rounded-full border border-white/10 bg-white/5 backdrop-blur-sm hover:border-purple-500/50 transition-colors"
            >
              <span className="text-white font-medium whitespace-nowrap">{tech}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
