"use client"

import { motion } from "framer-motion"
import {
  Globe,
  Smartphone,
  Cloud,
  Database,
  Brain,
  Shield,
} from "lucide-react"

const services = [
  {
    icon: Globe,
    title: "Web Development",
    description:
      "Custom web applications built with modern frameworks like Next.js, React, and Vue for optimal performance.",
  },
  {
    icon: Smartphone,
    title: "Mobile Apps",
    description:
      "Native and cross-platform mobile applications using React Native and Flutter for iOS and Android.",
  },
  {
    icon: Cloud,
    title: "Cloud Architecture",
    description:
      "Scalable cloud infrastructure design and deployment on AWS, GCP, and Azure platforms.",
  },
  {
    icon: Database,
    title: "Backend Systems",
    description:
      "Robust API development and microservices architecture with Node.js, Python, and Go.",
  },
  {
    icon: Brain,
    title: "AI Integration",
    description:
      "Machine learning models and AI-powered features to enhance your products.",
  },
  {
    icon: Shield,
    title: "Security & DevOps",
    description:
      "Enterprise-grade security implementation and CI/CD pipeline automation.",
  },
]

export function Services() {
  return (
    <section id="services" className="py-32 bg-black relative">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">
            What We Do
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-white mt-4">
            Our Services
          </h2>
          <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
            End-to-end software development services tailored to your business needs
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative"
            >
              <div className="relative p-8 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm overflow-hidden hover:border-blue-500/50 transition-all duration-500">
                {/* Shimmer effect */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                </div>

                {/* Border beam animation */}
                <div className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-blue-500 to-transparent animate-pulse" />
                  <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-purple-500 to-transparent animate-pulse" />
                </div>

                <div className="relative z-10">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-600/20 to-purple-600/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <service.icon className="w-7 h-7 text-blue-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-3">
                    {service.title}
                  </h3>
                  <p className="text-gray-400 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
