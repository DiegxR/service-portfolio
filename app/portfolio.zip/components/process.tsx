"use client"

import { useRef } from "react"
import { motion, useScroll, useTransform } from "framer-motion"
import {
  Search,
  Lightbulb,
  PenTool,
  Code2,
  TestTube,
  Rocket,
} from "lucide-react"

const steps = [
  {
    icon: Search,
    title: "Discovery",
    description:
      "We dive deep into understanding your business goals, target audience, and project requirements.",
  },
  {
    icon: Lightbulb,
    title: "Strategy",
    description:
      "Our team crafts a comprehensive roadmap with clear milestones and deliverables.",
  },
  {
    icon: PenTool,
    title: "Design",
    description:
      "Creating intuitive user experiences and stunning visual designs that align with your brand.",
  },
  {
    icon: Code2,
    title: "Development",
    description:
      "Building your solution with clean, scalable code using the latest technologies.",
  },
  {
    icon: TestTube,
    title: "Testing",
    description:
      "Rigorous quality assurance to ensure flawless performance across all platforms.",
  },
  {
    icon: Rocket,
    title: "Launch",
    description:
      "Seamless deployment and ongoing support to ensure your product succeeds.",
  },
]

export function Process() {
  const containerRef = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  })

  const lineHeight = useTransform(scrollYProgress, [0, 1], ["0%", "100%"])

  return (
    <section id="process" className="py-32 bg-black relative" ref={containerRef}>
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-20"
        >
          <span className="text-blue-400 text-sm font-medium tracking-wider uppercase">
            How We Work
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-white mt-4">
            Our Process
          </h2>
          <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
            A proven methodology that delivers results
          </p>
        </motion.div>

        <div className="relative">
          {/* Animated vertical line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 top-0 bottom-0 w-px bg-white/10">
            <motion.div
              className="absolute top-0 left-0 w-full bg-gradient-to-b from-blue-500 via-purple-500 to-blue-500"
              style={{ height: lineHeight }}
            />
          </div>

          {/* Steps */}
          <div className="space-y-24">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6 }}
                className={`flex items-center gap-8 ${
                  index % 2 === 0 ? "flex-row" : "flex-row-reverse"
                }`}
              >
                <div
                  className={`flex-1 ${
                    index % 2 === 0 ? "text-right" : "text-left"
                  }`}
                >
                  <div
                    className={`inline-block p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm max-w-md ${
                      index % 2 === 0 ? "ml-auto" : "mr-auto"
                    }`}
                  >
                    <h3 className="text-xl font-semibold text-white mb-2">
                      {step.title}
                    </h3>
                    <p className="text-gray-400 leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>

                {/* Center icon */}
                <div className="relative z-10 flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center shadow-lg shadow-blue-500/25">
                    <step.icon className="w-7 h-7 text-white" />
                  </div>
                </div>

                <div className="flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
